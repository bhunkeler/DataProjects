import pyspark
import socket
import time
from datetime import datetime

from pyspark import SparkContext

from urllib.parse import urlparse
from pyspark.sql.types import *
from pyspark.sql.functions import split
import socket, time


class Consumer():

    def __init__(self, port_number):

        self._sc = SparkContext()
        self._port_number = port_number
        pass 

    def getMasterNodeIP(self):
        '''
        get the IP from the master node
        '''
        try:
            
            url_parsed = urlparse(self._sc.uiWebUrl)
            ip = url_parsed.netloc.split(':')[0]
            return ip
        
        except Exception as exp:
            print(exp)
            return None

    def get_port_number(self):
        return self._port_number


    def data_preparation(self, lines):    

        # Split the lines by comma (and assign each resulting column a proper name to reflect its contents, using the alias function)
        # Note that wherever needed, we must also cast the resulting column to its proper type (e.g. Float for prices, instead of the default String)

        separator = ","

        structuredStream = lines.select(split(lines.value, separator)[0].cast('Int').alias("id"),\
                                        split(lines.value, separator)[1].alias("street"),\
                                        split(lines.value, separator)[2].alias("street_no"),\
                                        split(lines.value, separator)[3].cast('Int').alias("x_coord"),\
                                        split(lines.value, separator)[4].cast('Int').alias("y_coord"),\
                                        split(lines.value, separator)[5].cast('Float').alias("Ion"),\
                                        split(lines.value, separator)[6].cast('Float').alias("lat"),\
                                        split(lines.value, separator)[7].cast('Int').alias("filling_level"),\
                                        split(lines.value, separator)[8].cast('Timestamp').alias("timestamp"),\
                                        split(lines.value, separator)[9].cast('Bool').alias("maintenance"))

        return structuredStream


if __name__ == '__main__':

    consumer = Consumer()
    
    # Read input stream from socket (by default, sockets contain raw strings, which we must then parse in a structured format)
    lines = pyspark.readStream.format("socket")\
                              .option("host", consumer.getMasterNodeIP())\
                              .option("port", consumer.get_port_number())\
                              .load()

    structured_stream = consumer.data_preparation(lines)

