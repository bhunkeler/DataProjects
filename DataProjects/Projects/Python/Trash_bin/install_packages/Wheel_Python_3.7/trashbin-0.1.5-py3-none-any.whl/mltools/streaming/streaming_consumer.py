from pyspark.sql.functions import *
import time



class Streaming_Consumer():
    
    def __init__(self):
        pass
 
    def printDF(self, streaming_df):
        '''
        Helper function to print a few dataframe statistics: count, top rows

        arguments:
        ----------
        streaming_df - stream data as dataframe

        return:
        -------

        '''
        iter = 0
        while iter < 10:
            if(streaming_df.count() > 0):
                print("Number of entries in dataframe: " + str(streaming_df.count()))
                streaming_df.show(20, False) # the parameter False prevents Spark from truncating the output
                iter += 1
            time.sleep(2)

    def create_stream(self, spark, json_schema):
        # create the stream from the /tmp/tweets folder

        inputPath = "/tmp/tweets/"

        streaming_input_df = (
        spark
            .readStream
            .schema(json_schema)
            .json(inputPath)
        )

        # Check if this is streaming dataframe
        is_stream = streaming_input_df.isStreaming

        return streaming_input_df, is_stream

    def location_extraction(self, spark, streaming_input_df):

        streaming_etl_query = streaming_input_df \
        .select("id", "user.location")\
        .writeStream \
        .format("memory") \
        .queryName("tweetstream") \
        .outputMode("append")\
        .start()
        
        streaming_df = spark.sql("select count(*) as count, location from tweetstream group by location order by count desc")
        
        return streaming_etl_query, streaming_df

    def trend_analysis(self, spark, streaming_input_df):
        '''
        which trash_bins are filled most frequent 
        '''
        trend_trash_bins = streaming_input_df \
        .select(explode(streaming_input_df.entities.hashtags.text).alias("hashtag"))\
        .groupBy("hashtag")\
            .count()\
            .orderBy(desc("count"))
            
        query = trend_trash_bins \
            .writeStream \
            .queryName("trendingHashTags") \
            .format("memory") \
            .outputMode("complete") \
            .start()
        
        # leave some time for the stream to initialize  
        time.sleep(5)

        streamingDF = spark.sql("select * from trendingHashTags")


        pass

    def plot_filling_level(self):
        '''
        Plot a bar graph of filling levels for each trash_bins
        '''
        pass

    def hardware_failure_analysis(self):
        '''
        Analyse haow often Hardware fails and in what location 
        '''
        pass 

        