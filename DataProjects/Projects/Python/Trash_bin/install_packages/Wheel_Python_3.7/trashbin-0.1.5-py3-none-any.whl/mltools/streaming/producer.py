import pyspark
import socket
import time
from datetime import datetime

from pyspark import SparkContext

from urllib.parse import urlparse
from pyspark.sql.types import *
from pyspark.sql.functions import *
import socket, time



class Producer():

    def __init__(self, port_number):

        self._sc = SparkContext()
        self._port_number = port_number
        pass 

    def getMasterNodeIP(self):
        '''
        get the IP from the master node
        '''
        try:
            
            url_parsed = urlparse(self._sc.uiWebUrl)
            ip = url_parsed.netloc.split(':')[0]
            return ip
        
        except Exception as exp:
            print(exp)
            return None


    def send(self, inputFile):
        ifile  = open(inputFile, 'r') 
        i = 0
                
        while True:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            client_socket.bind((self.getMasterNodeIP(), self._portNumber))
            client_socket.listen(10)
            conn, addr = client_socket.accept()

            try:  
                while True:
                    start = time.time()
                    ifile  = open(inputFile, 'r') 
                    for row in ifile.readlines() :

                        print("sending: "+ row.rstrip() + "," + str(datetime.datetime.now()))
                        message = row.rstrip() + ',' + str(datetime.now()) + "\n"
                        message = message.encode()
                        conn.send(message)

                        # send data every 100 ms
                        time.sleep(0.1)
                            
            except Exception as e:
                if e.errno == 32:
                    # Broken Pipe Exception
                    print("Socket was closed. Re-initializing")
                else:
                    print(str(e))
                    conn.close()
                    client_socket.close()
                    continue
            finally:
                conn.close()
                client_socket.close()